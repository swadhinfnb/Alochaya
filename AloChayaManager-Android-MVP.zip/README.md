# AloChaya Photography Manager — Android MVP

Native Android starter project for an owner-only photography business manager.

## Included in this MVP
- Dashboard with booked revenue, received payments, expenses, outstanding client balances, and estimated event profit.
- Local Room database entities for clients, events, cash transactions, and employee payments.
- Add/list events and record income/expense transactions.
- Event-level cost and profit calculation.
- Google Drive integration scaffold and a manual Drive-link workflow.
- Bangladeshi Taka (৳) formatting.

## Important limits
This is source code, not a compiled APK. It must be built with Android Studio/Gradle.
Google Drive upload is not enabled until you configure a Google Cloud project, OAuth consent screen, Android OAuth client (package name + SHA-1), and add your own configuration. Never place a service-account private key or OAuth client secret inside an APK.
The Drive screen currently provides a safe integration entry point and saved-link workflow; direct upload requires the OAuth setup and implementation in `DriveRepository.kt`.

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder as a project.
3. Allow Gradle sync.
4. If Android Studio asks to install the configured SDK, install it.
5. Run on an Android device/emulator.
6. To produce an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Package name
`com.alochaya.manager`

Keep this package name consistent when configuring your Google Cloud Android OAuth client.

## Data and backups
The database is local to the phone in this starter version. Uninstalling the app or clearing its data can erase records. Add an encrypted export/backup and restore workflow before relying on it for business-critical accounting. This MVP does not send accounting data to any server.

## Suggested next milestones
1. Configure Google OAuth and implement Drive upload + share-link creation.
2. Add PDF invoice/quotation generation.
3. Add package catalogue and public package-selection link.
4. Add CSV/Excel export, database backup/restore, PIN/biometric lock, and audit log.
