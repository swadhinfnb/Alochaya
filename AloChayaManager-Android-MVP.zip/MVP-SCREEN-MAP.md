# MVP screen map

1. **Home** — cash received, expense/team paid, rough client balance, event count, estimated event profit.
2. **Bookings** — create event with client, date, package name and agreed value; save Drive folder, preview and final links; delivery status.
3. **Cashbook** — add actual income or expense, optionally link it to an event.
4. **Team** — agreed freelancer/employee pay, paid amount, outstanding amount.
5. **Database** — Room / SQLite, local-only in this version.

## Accounting caveats to resolve before production
- Client receipts must be linked to events for accurate per-event revenue and client balances.
- Employee payments should become separate payment records linked to a staff ledger; current MVP stores one agreed-pay record with a paid amount.
- Monthly reports need date-range filtering and period close/reconciliation.
- A business-grade version should include edit/delete audit history, backup/restore, and data export.
