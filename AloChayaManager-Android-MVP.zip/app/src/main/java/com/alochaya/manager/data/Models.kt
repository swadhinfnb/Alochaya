package com.alochaya.manager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val notes: String = ""
)

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long = 0,
    val clientName: String,
    val title: String,
    val eventDate: String,
    val packageName: String = "",
    val agreedAmount: Double = 0.0,
    val driveFolderUrl: String = "",
    val previewUrl: String = "",
    val deliveryUrl: String = "",
    val deliveryStatus: String = "Not started",
    val notes: String = ""
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventId: Long? = null,
    val date: String,
    val type: String, // INCOME or EXPENSE
    val category: String,
    val amount: Double,
    val description: String = ""
)

@Entity(tableName = "employee_payments")
data class EmployeePaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventId: Long? = null,
    val employeeName: String,
    val agreedPay: Double,
    val paidAmount: Double = 0.0,
    val date: String,
    val notes: String = ""
)
