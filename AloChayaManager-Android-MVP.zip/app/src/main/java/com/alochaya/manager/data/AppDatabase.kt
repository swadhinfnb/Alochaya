package com.alochaya.manager.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM clients ORDER BY name") fun clients(): Flow<List<ClientEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addClient(client: ClientEntity): Long

    @Query("SELECT * FROM events ORDER BY eventDate DESC") fun events(): Flow<List<EventEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addEvent(event: EventEntity): Long
    @Query("UPDATE events SET driveFolderUrl=:folder, previewUrl=:preview, deliveryUrl=:delivery, deliveryStatus=:status WHERE id=:id")
    suspend fun updateDelivery(id: Long, folder: String, preview: String, delivery: String, status: String)

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC") fun transactions(): Flow<List<TransactionEntity>>
    @Insert suspend fun addTransaction(transaction: TransactionEntity): Long

    @Query("SELECT * FROM employee_payments ORDER BY date DESC") fun employeePayments(): Flow<List<EmployeePaymentEntity>>
    @Insert suspend fun addEmployeePayment(payment: EmployeePaymentEntity): Long
}

@Database(
    entities = [ClientEntity::class, EventEntity::class, TransactionEntity::class, EmployeePaymentEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "alochaya_manager.db"
            ).build().also { INSTANCE = it }
        }
    }
}
