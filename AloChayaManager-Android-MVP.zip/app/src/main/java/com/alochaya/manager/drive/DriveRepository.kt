package com.alochaya.manager.drive

import android.net.Uri

/**
 * Google Drive integration boundary.
 *
 * Before enabling uploads:
 * - Create a Google Cloud project and enable Google Drive API.
 * - Configure OAuth consent screen and an Android OAuth client for
 *   applicationId com.alochaya.manager plus your signing SHA-1.
 * - Request the narrowest suitable Drive scope.
 * - Use Google Identity authorization flow; do not embed client secrets or
 *   service-account private keys in the APK.
 *
 * This class intentionally does not fake upload success. The current MVP lets
 * the owner save Drive folder / preview / delivery URLs on each event.
 */
class DriveRepository {
    fun validateShareUrl(raw: String): String? {
        val uri = runCatching { Uri.parse(raw.trim()) }.getOrNull() ?: return null
        return if (uri.scheme == "https" &&
            (uri.host == "drive.google.com" || uri.host == "docs.google.com")) {
            uri.toString()
        } else null
    }

    fun uploadNotConfiguredMessage(): String =
        "Google Drive upload is not configured yet. Add Google OAuth credentials and complete DriveRepository integration."
}
