package com.alochaya.manager

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alochaya.manager.data.*
import com.alochaya.manager.drive.DriveRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFFE1C27A),
                background = androidx.compose.ui.graphics.Color(0xFF101010),
                surface = androidx.compose.ui.graphics.Color(0xFF1B1B1B)
            )) {
                Surface(Modifier.fillMaxSize()) {
                    AloChayaApp(db.dao())
                }
            }
        }
    }
}

class ManagerViewModel(private val dao: AppDao) : ViewModel() {
    val events = dao.events().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val transactions = dao.transactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val employees = dao.employeePayments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val clients = dao.clients().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addEvent(client: String, title: String, date: String, pkg: String, amount: Double) =
        viewModelScope.launch {
            val clientId = dao.addClient(ClientEntity(name = client.trim()))
            dao.addEvent(EventEntity(
                clientId = clientId, clientName = client.trim(), title = title.trim(),
                eventDate = date.trim(), packageName = pkg.trim(), agreedAmount = amount
            ))
        }

    fun addTransaction(eventId: Long?, date: String, type: String, category: String, amount: Double, description: String) =
        viewModelScope.launch {
            dao.addTransaction(TransactionEntity(
                eventId = eventId, date = date.trim(), type = type,
                category = category.trim(), amount = amount, description = description.trim()
            ))
        }

    fun addEmployee(name: String, agreed: Double, paid: Double, date: String, eventId: Long?) =
        viewModelScope.launch {
            dao.addEmployeePayment(EmployeePaymentEntity(
                eventId = eventId, employeeName = name.trim(), agreedPay = agreed,
                paidAmount = paid, date = date.trim()
            ))
        }

    fun updateDelivery(event: EventEntity, folder: String, preview: String, delivery: String, status: String) =
        viewModelScope.launch { dao.updateDelivery(event.id, folder, preview, delivery, status) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AloChayaApp(dao: AppDao) {
    val vm = remember { ManagerViewModel(dao) }
    val events by vm.events.collectAsState()
    val txs by vm.transactions.collectAsState()
    val employees by vm.employees.collectAsState()
    val clients by vm.clients.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showEvent by remember { mutableStateOf(false) }
    var showTransaction by remember { mutableStateOf(false) }
    var showEmployee by remember { mutableStateOf(false) }
    var deliveryEvent by remember { mutableStateOf<EventEntity?>(null) }

    val received = txs.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expenses = txs.filter { it.type == "EXPENSE" }.sumOf { it.amount } +
        employees.sumOf { it.paidAmount }
    val clientDue = (events.sumOf { it.agreedAmount } - received).coerceAtLeast(0.0)
    val eventProfit = events.sumOf { event ->
        val income = txs.filter { it.eventId == event.id && it.type == "INCOME" }.sumOf { it.amount }
        val costs = txs.filter { it.eventId == event.id && it.type == "EXPENSE" }.sumOf { it.amount } +
            employees.filter { it.eventId == event.id }.sumOf { it.agreedPay }
        income - costs
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("AloChaya", fontWeight = FontWeight.Bold)
                    Text("PHOTOGRAPHY MANAGER", style = MaterialTheme.typography.labelSmall)
                } },
                actions = { Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.padding(end = 16.dp)) }
            )
        },
        floatingActionButton = {
            when (tab) {
                1 -> FloatingActionButton(onClick = { showEvent = true }) { Icon(Icons.Default.Add, "Add event") }
                2 -> FloatingActionButton(onClick = { showTransaction = true }) { Icon(Icons.Default.Add, "Add transaction") }
                3 -> FloatingActionButton(onClick = { showEmployee = true }) { Icon(Icons.Default.Add, "Add employee payment") }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Event, null) }, label = { Text("Bookings") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Payments, null) }, label = { Text("Cashbook") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Groups, null) }, label = { Text("Team") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> Dashboard(received, expenses, clientDue, eventProfit, events.size, onBookings = { tab = 1 }, onCash = { tab = 2 })
                1 -> BookingsScreen(events, onDelivery = { deliveryEvent = it })
                2 -> CashbookScreen(txs)
                3 -> TeamScreen(employees)
            }
        }
    }

    if (showEvent) AddEventDialog(
        onDismiss = { showEvent = false },
        onSave = { client, title, date, pkg, amount ->
            vm.addEvent(client, title, date, pkg, amount); showEvent = false
        }
    )
    if (showTransaction) AddTransactionDialog(
        events = events, onDismiss = { showTransaction = false },
        onSave = { eventId, date, type, category, amount, description ->
            vm.addTransaction(eventId, date, type, category, amount, description); showTransaction = false
        }
    )
    if (showEmployee) AddEmployeeDialog(
        events = events, onDismiss = { showEmployee = false },
        onSave = { name, agreed, paid, date, eventId ->
            vm.addEmployee(name, agreed, paid, date, eventId); showEmployee = false
        }
    )
    deliveryEvent?.let { event ->
        DeliveryDialog(event, onDismiss = { deliveryEvent = null }, onSave = { folder, preview, finalLink, status ->
            vm.updateDelivery(event, folder, preview, finalLink, status)
            deliveryEvent = null
        })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dashboard(received: Double, expenses: Double, due: Double, profit: Double, count: Int, onBookings: () -> Unit, onCash: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Business overview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Your studio, one place.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Received", money(received), Modifier.weight(1f))
            MetricCard("Expenses + paid team", money(expenses), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Client balance*", money(due), Modifier.weight(1f))
            MetricCard("Events", count.toString(), Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Estimated event profit", style = MaterialTheme.typography.titleMedium)
                Text(money(profit), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Based on recorded event income, expenses and agreed team pay.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("*Client balance is a rough total until payments are linked to the correct events.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onBookings, modifier = Modifier.fillMaxWidth()) { Text("Manage bookings") }
        OutlinedButton(onClick = onCash, modifier = Modifier.fillMaxWidth()) { Text("Open cashbook") }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BookingsScreen(events: List<EventEntity>, onDelivery: (EventEntity) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Bookings & delivery", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (events.isEmpty()) EmptyMessage("No bookings yet", "Tap + to add your first client booking.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(events, key = { it.id }) { event ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(event.clientName + " • " + event.eventDate)
                        Text("Package: ${event.packageName.ifBlank { "Not set" }}")
                        Text("Booking value: ${money(event.agreedAmount)}")
                        Text("Delivery: ${event.deliveryStatus}", color = MaterialTheme.colorScheme.primary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { onDelivery(event) }) { Text("Drive / Delivery links") }
                            if (event.previewUrl.isNotBlank()) TextButton(onClick = { openLink(context, event.previewUrl) }) { Text("Preview") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CashbookScreen(txs: List<TransactionEntity>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Cashbook", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Record money actually received or spent.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        if (txs.isEmpty()) EmptyMessage("Cashbook is empty", "Tap + to record income or an expense.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(txs, key = { it.id }) { tx ->
                ListItem(
                    headlineContent = { Text(tx.category + " — " + money(tx.amount)) },
                    supportingContent = { Text("${tx.date} • ${tx.description}") },
                    leadingContent = { Icon(if (tx.type == "INCOME") Icons.Default.CallReceived else Icons.Default.CallMade, null) },
                    trailingContent = { Text(if (tx.type == "INCOME") "IN" else "OUT", color = if (tx.type == "INCOME") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun TeamScreen(payments: List<EmployeePaymentEntity>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Team ledger", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Agreed pay, amount paid, and remaining balance.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        if (payments.isEmpty()) EmptyMessage("No team payments yet", "Tap + to record a worker's agreed payment.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(payments, key = { it.id }) { p ->
                val due = (p.agreedPay - p.paidAmount).coerceAtLeast(0.0)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(p.employeeName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Agreed: ${money(p.agreedPay)} • Paid: ${money(p.paidAmount)}")
                        Text("Remaining: ${money(due)}", color = if (due > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        Text(p.date, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyMessage(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Inbox, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AddEventDialog(onDismiss: () -> Unit, onSave: (String, String, String, String, Double) -> Unit) {
    var client by remember { mutableStateOf("") }; var title by remember { mutableStateOf("Wedding Photography") }
    var date by remember { mutableStateOf("") }; var pkg by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("New booking") }, text = {
        Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(client, { client = it }, label = { Text("Client name *") }, singleLine = true)
            OutlinedTextField(title, { title = it }, label = { Text("Event type / title *") }, singleLine = true)
            OutlinedTextField(date, { date = it }, label = { Text("Event date (YYYY-MM-DD) *") }, singleLine = true)
            OutlinedTextField(pkg, { pkg = it }, label = { Text("Package name") }, singleLine = true)
            OutlinedTextField(amount, { amount = it }, label = { Text("Agreed amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { if (client.isNotBlank() && title.isNotBlank() && date.isNotBlank()) onSave(client, title, date, pkg, amount.toDoubleOrNull() ?: 0.0) }) { Text("Save booking") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun AddTransactionDialog(events: List<EventEntity>, onDismiss: () -> Unit, onSave: (Long?, String, String, String, Double, String) -> Unit) {
    var date by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var type by remember { mutableStateOf("INCOME") }; var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var selectedEvent by remember { mutableStateOf(0L) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Cash transaction") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == "INCOME", onClick = { type = "INCOME" }, label = { Text("Income") })
                FilterChip(selected = type == "EXPENSE", onClick = { type = "EXPENSE" }, label = { Text("Expense") })
            }
            OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true)
            OutlinedTextField(category, { category = it }, label = { Text("Category (e.g. advance, travel)") }, singleLine = true)
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(desc, { desc = it }, label = { Text("Note / client / vendor") })
            Text("Link to event (optional)", style = MaterialTheme.typography.labelMedium)
            events.take(8).forEach { event ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selectedEvent == event.id, onClick = { selectedEvent = event.id })
                    Text("${event.clientName} — ${event.title}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { if (category.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) onSave(selectedEvent.takeIf { it != 0L }, date, type, category, amount.toDoubleOrNull() ?: 0.0, desc) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun AddEmployeeDialog(events: List<EventEntity>, onDismiss: () -> Unit, onSave: (String, Double, Double, String, Long?) -> Unit) {
    var name by remember { mutableStateOf("") }; var agreed by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("0") }; var date by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var selectedEvent by remember { mutableStateOf(0L) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Team payment") }, text = {
        Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Employee / freelancer name") }, singleLine = true)
            OutlinedTextField(agreed, { agreed = it }, label = { Text("Agreed pay (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(paid, { paid = it }, label = { Text("Already paid (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true)
            Text("Related event (optional)")
            events.take(8).forEach { event ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selectedEvent == event.id, onClick = { selectedEvent = event.id })
                    Text("${event.clientName} — ${event.title}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { if (name.isNotBlank() && (agreed.toDoubleOrNull() ?: 0.0) >= 0) onSave(name, agreed.toDoubleOrNull() ?: 0.0, paid.toDoubleOrNull() ?: 0.0, date, selectedEvent.takeIf { it != 0L }) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun DeliveryDialog(event: EventEntity, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var folder by remember { mutableStateOf(event.driveFolderUrl) }
    var preview by remember { mutableStateOf(event.previewUrl) }
    var delivery by remember { mutableStateOf(event.deliveryUrl) }
    var status by remember { mutableStateOf(event.deliveryStatus) }
    val statuses = listOf("Not started", "Editing", "Preview sent", "Awaiting selection", "Final delivered")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Drive / delivery links") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${event.clientName} • ${event.title}", fontWeight = FontWeight.Bold)
            OutlinedTextField(folder, { folder = it }, label = { Text("Google Drive folder URL") })
            OutlinedTextField(preview, { preview = it }, label = { Text("Preview gallery URL") })
            OutlinedTextField(delivery, { delivery = it }, label = { Text("Final delivery URL") })
            Text("Delivery status")
            statuses.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = status == s, onClick = { status = s }); Text(s)
            } }
            Text("Current version stores links only; direct Drive upload needs Google OAuth setup.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { onSave(folder, preview, delivery, status) }) { Text("Save links") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

fun money(value: Double): String = "৳" + NumberFormat.getNumberInstance(Locale("en", "BD")).format(value)
fun openLink(context: android.content.Context, url: String) {
    val uri = runCatching { Uri.parse(url.trim()) }.getOrNull() ?: return
    if (uri.scheme != "https") return
    val host = uri.host.orEmpty()
    if (host != "drive.google.com" && host != "docs.google.com") return
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
}
